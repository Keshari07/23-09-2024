# embedded-tomcat-war-deploy
This will deploy the custom war file to embedded tomcat server.

Pull the code and import in your eclipse/IntelliJ.

mvn clean install will deploy required dependencies.

Resources folder contains sample (simplewar.war) war file. 

When we run Test.java as java application simplewar will be deployed in server and serving from browser as /simplewar

