package com.star.sud.rest.bean;

public class HelloBean {

	private String message;

	public HelloBean() {
		super();
	}

	public HelloBean(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
