var tomcatDeployment = require("./tomcatDeployment");
tomcatDeployment.deploy();