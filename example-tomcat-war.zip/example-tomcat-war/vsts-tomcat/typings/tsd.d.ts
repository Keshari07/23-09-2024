/// <reference path="mocha/mocha.d.ts" />
/// <reference path="node/node.d.ts" />
/// <reference path="shelljs/shelljs.d.ts" />
/// <reference path="sinon/sinon.d.ts" />
/// <reference path="assertion-error/assertion-error.d.ts" />
/// <reference path="chai/chai.d.ts" />
/// <reference path="sinon-chai/sinon-chai.d.ts" />
/// <reference path="q/Q.d.ts" />
